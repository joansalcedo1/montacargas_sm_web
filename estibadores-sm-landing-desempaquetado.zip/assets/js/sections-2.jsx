// More sections — Services, WhyUs, Gallery, CTA, Footer

const { useState: useState2 } = React;
const Icon = window.Ico;
const Reveal = window.Reveal;
const CountUp = window.CountUp;



/* ─────────── SERVICES ─────────── */

function Services({ accent }) {

  const items = [

    { i: 'Wrench',   t: 'Reparación de montacargas',  d: 'Diagnóstico, mecánica, hidráulica y eléctrica. Técnicos certificados con repuestos originales.', tag: '01' },

    { i: 'Box',      t: 'Venta de repuestos',         d: 'Inventario propio de partes para marcas Toyota, Hyster, Yale, Crown y Linde.', tag: '02' },

    { i: 'Forklift', t: 'Venta de repuestos', d: 'Stock completo para Hyster, Caterpillar, TCM, Komatsu, Yale, Nissan, Clark, Toyota y más. Llantas, baterías y componentes críticos para cualquier necesidad técnica.', tag: '03' },

    { i: 'Gear',     t: 'Mantenimiento preventivo',   d: 'Planes mensuales con bitácora digital y reportes ejecutivos para tu equipo de operaciones.', tag: '04' },

    { i: 'Headset',  t: 'Soporte técnico',            d: 'Mesa de ayuda 24/7. Atención remota inmediata y desplazamiento garantizado en menos de 4 horas.', tag: '05' },

    { i: 'Bolt',     t: 'Estibadores eléctricos',     d: 'Pallet jacks eléctricos y manuales de 1.5 a 3 toneladas para bodegaje y picking intensivo.', tag: '06' },

  ];



  return (

    <section id="servicios" className="relative py-28 lg:py-36 bg-bone">

      <div className="absolute inset-0 blueprint opacity-50 pointer-events-none"></div>

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">

        <div className="grid lg:grid-cols-12 gap-10 items-end mb-16">

          <div className="lg:col-span-7">

            <div className="font-mono text-[11px] tracking-[0.3em] text-deep mb-4">/ 01 — QUÉ HACEMOS</div>

            <h2 className="font-head text-[clamp(44px,6vw,84px)] leading-[0.92] uppercase text-ink">

              Servicios integrales<br/>

              para mover tu <span className="underline-amber">operación</span>.

            </h2>

          </div>

          <div className="lg:col-span-5 text-[15px] text-ink/70 leading-relaxed lg:pl-10 lg:border-l border-ink/10">

            Cubrimos el ciclo completo del equipo de manejo de materiales: desde el suministro hasta la baja técnica. Una sola empresa, una sola factura, cero interrupciones.

          </div>

        </div>



        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-ink/10">

          {items.map((s, idx) => {

            const I = Icon[s.i];

            return (

              <Reveal key={s.tag} delay={idx * 60}>

                <article className="lift group relative bg-bone p-8 lg:p-10 h-full border border-transparent flex flex-col">

                  <div className="flex items-start justify-between mb-8">

                    <div className="w-14 h-14 flex items-center justify-center bg-ink text-bone group-hover:bg-deep transition-colors">

                      <I className="w-7 h-7"/>

                    </div>

                    <span className="font-mono text-[11px] text-ink/40">{s.tag}</span>

                  </div>

                  <h3 className="font-head text-3xl uppercase leading-tight text-ink">{s.t}</h3>

                  <p className="mt-3 text-[14px] text-ink/65 leading-relaxed">{s.d}</p>

                  <a href="#contacto" className="mt-6 inline-flex items-center gap-2 text-[13px] font-semibold text-deep">

                    Solicitar <Icon.Arrow className="w-4 h-4 transition-transform group-hover:translate-x-1"/>

                  </a>

                  <span className="absolute left-0 bottom-0 h-[3px] w-0 group-hover:w-full transition-all duration-500" style={{ background: accent }}></span>

                </article>

              </Reveal>

            );

          })}

        </div>

      </div>

    </section>

  );

}



/* ─────────── WHY US ─────────── */

function WhyUs({ accent }) {

  const stats = [

    { n: 10,  suffix: '+', k: 'AÑOS DE EXPERIENCIA',  d: 'operando con clientes industriales' },

    { n: 450, suffix: '+', k: 'EQUIPOS ATENDIDOS',    d: 'en bodegas y plantas activas' },

    { n: 4,   suffix: 'h', k: 'TIEMPO DE RESPUESTA',  d: 'promedio en sitio en zona urbana' },

    { n: 98,  suffix: '%', k: 'CUMPLIMIENTO SLA',     d: 'medido sobre 2 400 visitas en 2025' },

    { n: 24,  suffix: '/7',k: 'SOPORTE TÉCNICO',      d: 'mesa de ayuda y técnicos en turno' },

  ];



  const reasons = [

    'Técnicos certificados por marcas',

    'Repuestos originales en stock',

    'Servicio en todo el Valle del Cauca',

    'Bitácora digital por equipo',

    'Operarios con licencia C2 vigente',

  ];



  return (

    <section id="nosotros" className="relative py-28 lg:py-36 bg-ink text-bone overflow-hidden">

      <div className="absolute -top-24 -right-24 w-[420px] h-[420px] rounded-full opacity-10" style={{ background: accent, filter: 'blur(120px)' }}></div>

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">

        <div className="grid lg:grid-cols-12 gap-10 mb-16">

          <div className="lg:col-span-6">

            <div className="font-mono text-[11px] tracking-[0.3em] text-bone/60 mb-4">/ 02 — POR QUÉ ELEGIRNOS</div>

            <h2 className="font-head text-[clamp(44px,6vw,84px)] leading-[0.92] uppercase">

              Reparación experta.<br/>

              <span style={{ color: accent }}>Máxima continuidad</span><br/>

              en su operación.

            </h2>

          </div>

          <div className="lg:col-span-5 lg:col-start-8 text-[15px] text-bone/70 leading-relaxed">

            <p>Cuando su operación se detiene, el costo se mide en minutos perdidos. Nuestro modelo combina técnicos expertos, repuestos originales inmediatos y un compromiso total con la reparación de sus equipos.</p>

            <ul className="mt-6 space-y-2.5">

              {reasons.map((r, i) => (

                <li key={i} className="flex items-start gap-3 text-bone/85">

                  <span className="mt-2 inline-block w-3 h-[2px] shrink-0" style={{ background: accent }}></span>

                  <span className="text-[14.5px]">{r}</span>

                </li>

              ))}

            </ul>

          </div>

        </div>



        {/* stats grid */}

        <div className="grid grid-cols-2 lg:grid-cols-5 gap-px bg-bone/10 border border-bone/10">

          {stats.map((s, i) => (

            <Reveal key={s.k} delay={i * 80}>

              <div className="bg-ink p-7 lg:p-8 h-full group hover:bg-deep transition-colors duration-300">

                <div className="font-head text-[72px] lg:text-[88px] leading-none tracking-tight" style={{ color: accent }}>

                  <CountUp to={s.n} suffix={s.suffix}/>

                </div>

                <div className="mt-3 font-mono text-[10.5px] tracking-[0.25em] text-bone/80">{s.k}</div>

                <div className="mt-1 text-[12.5px] text-bone/55 leading-snug">{s.d}</div>

              </div>

            </Reveal>

          ))}

        </div>

      </div>

    </section>

  );

}



/* ─────────── GALLERY / EQUIPOS ─────────── */

function Gallery({ accent }) {

  const tabs = [

    { id: 'electric', label: 'Montacargas eléctricos' },

    { id: 'manual',   label: 'Estibadores manuales' },

    { id: 'indust',   label: 'Equipos industriales' },

    { id: 'bodega',   label: 'Operaciones en bodega' },

  ];

  const [active, setActive] = useState2('electric');



  const equipos = {

    electric: [

      { t: 'EM-25 Litio',     m: 'Toyota · 8FBN25',   spec: '2.5T · 4.8m · 80V', ph: 'eléctrico contrabalanceado' },

      { t: 'EM-30 Tri-Wheel', m: 'Hyster · J3.0XN',   spec: '3.0T · 6.0m · 48V', ph: 'eléctrico tres ruedas' },

      { t: 'EM-18 Reach',     m: 'Crown · ESR5260',   spec: '1.8T · 8.5m · 36V', ph: 'reach truck eléctrico' },

    ],

    manual: [

      { t: 'PM-22 Tradicional', m: 'Crown · PTH50',   spec: '2.2T · estiba doble', ph: 'estibador manual' },

      { t: 'PM-15 Tijera',      m: 'Pramac · GS15',   spec: '1.5T · 800mm',        ph: 'estibador tijera' },

      { t: 'PE-20 Eléctrico',   m: 'Linde · MT15',    spec: '2.0T · litio',        ph: 'estibador eléctrico' },

    ],

    indust: [

      { t: 'Apilador eléctrico',  m: 'Yale · MS14',    spec: '1.4T · 3.5m',  ph: 'apilador walkie' },

      { t: 'Picking de bajo nivel', m: 'Crown · GPC',   spec: '2.4T · 200mm', ph: 'order picker' },

      { t: 'Tractor de arrastre', m: 'Linde · P30',    spec: '3.0T · remolque', ph: 'tractor logístico' },

    ],

    bodega: [

      { t: 'Centro de distribución', m: 'Cliente alimentos', spec: '12 000 m²', ph: 'CD frío' },

      { t: 'Bodega de paqueteo',     m: 'Cliente retail',    spec: '8 turnos / día', ph: 'cross-docking' },

      { t: 'Patio de maniobras',     m: 'Cliente cementero', spec: 'operación 24/7', ph: 'patio industrial' },

    ],

  };



  return (

    <section id="equipos" className="relative py-28 lg:py-36 bg-bone">

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">

        <div className="flex flex-wrap items-end justify-between gap-8 mb-12">

          <div>

            <div className="font-mono text-[11px] tracking-[0.3em] text-deep mb-4">/ 03 — EQUIPOS &amp; GALERÍA</div>

            <h2 className="font-head text-[clamp(44px,6vw,84px)] leading-[0.92] uppercase text-ink">

              Flota lista para<br/>operar hoy mismo.

            </h2>

          </div>

          <p className="max-w-md text-[15px] text-ink/65 leading-relaxed">Expertos en mantenimiento multimarca: Hyster, Caterpillar, TCM, Komatsu, Yale, Nissan, Clark, Toyota. Atendemos todo tipo de necesidades técnicas con repuestos originales y técnicos certificados.</p>

        </div>



        {/* tabs */}

        <div className="flex flex-wrap gap-2 mb-10 border-b border-ink/10">

          {tabs.map(tb => (

            <button key={tb.id}

              onClick={() => setActive(tb.id)}

              className={`relative px-4 lg:px-5 py-3 text-[13px] font-semibold tracking-wide uppercase transition-colors ${active === tb.id ? 'text-ink' : 'text-ink/45 hover:text-ink/80'}`}>

              {tb.label}

              {active === tb.id && <span className="absolute left-0 right-0 -bottom-px h-[3px]" style={{ background: accent }}></span>}

            </button>

          ))}

        </div>



        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">

          {equipos[active].map((e, idx) => (

            <Reveal key={e.t + active} delay={idx * 70}>

              <article className="lift group relative bg-bone overflow-hidden border border-ink/10">

                {/* placeholder image */}

                <div className="relative aspect-[4/3] ph-stripes-light overflow-hidden">

                  {/* faux silhouette */}

                  <svg className="absolute inset-0 w-full h-full opacity-30" viewBox="0 0 400 300" fill="none" stroke="#243982" strokeWidth="1.5">

                    <path d="M60 220h220V120h60l30 60v40H60Z"/>

                    <path d="M320 120v120M320 140h60"/>

                    <path d="M60 130v90M60 130h20v90M90 130h20v90"/>

                    <circle cx="120" cy="240" r="22"/><circle cx="240" cy="240" r="22"/>

                  </svg>

                  <span className="absolute top-3 left-3 inline-flex items-center gap-2 px-2.5 py-1 bg-ink text-bone font-mono text-[10px] tracking-[0.2em]">

                    <span className="w-1.5 h-1.5 rounded-full" style={{ background: accent }}></span>

                    DISPONIBLE

                  </span>

                  <span className="absolute bottom-3 right-3 font-mono text-[10px] tracking-[0.2em] text-ink/40">[ {e.ph} ]</span>

                  <div className="absolute inset-0 bg-deep/0 group-hover:bg-deep/40 transition-colors flex items-center justify-center">

                    <span className="opacity-0 group-hover:opacity-100 transition-opacity inline-flex items-center gap-2 px-4 py-2 bg-bone text-ink font-semibold text-[13px]">

                      Ver ficha técnica <Icon.Arrow className="w-4 h-4"/>

                    </span>

                  </div>

                </div>

                <div className="p-6">

                  <div className="flex items-center justify-between">

                    <span className="font-mono text-[10.5px] tracking-[0.25em] text-ink/45">{e.m}</span>

                    <span className="font-mono text-[10.5px] text-deep">#{(idx+1).toString().padStart(2,'0')}</span>

                  </div>

                  <h3 className="mt-2 font-head text-3xl uppercase leading-tight text-ink">{e.t}</h3>

                  <div className="mt-3 flex items-center justify-between">

                    <span className="text-[13px] text-ink/70 font-medium">{e.spec}</span>

                    <span className="inline-flex items-center gap-1 text-[12px] font-semibold text-deep">

                      Cotizar <Icon.Arrow className="w-3.5 h-3.5"/>

                    </span>

                  </div>

                </div>

              </article>

            </Reveal>

          ))}

        </div>

      </div>

    </section>

  );

}



/* ─────────── CTA ─────────── */

function CTA({ accent }) {

  return (

    <section className="relative py-24 lg:py-32 bg-deep text-bone overflow-hidden">

      {/* hazard accent corners */}

      <div className="absolute top-0 left-0 right-0 h-[6px] hazard"></div>

      <div className="absolute bottom-0 left-0 right-0 h-[6px] hazard"></div>

      {/* diagonal accent */}

      <div className="absolute -right-40 -top-40 w-[600px] h-[600px] rotate-12 opacity-[0.06]" style={{ background: `repeating-linear-gradient(0deg, ${accent} 0 2px, transparent 2px 22px)` }}></div>



      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10 grid lg:grid-cols-12 gap-10 items-center">

        <div className="lg:col-span-8">

          <div className="font-mono text-[11px] tracking-[0.3em] mb-5" style={{ color: accent }}>/ HABLEMOS DE TU OPERACIÓN</div>

          <h2 className="font-head text-[clamp(48px,7vw,108px)] leading-[0.9] uppercase">

            Optimiza tu<br/>

            operación logística<br/>

            <span style={{ color: accent }}>hoy.</span>

          </h2>

          <p className="mt-6 max-w-xl text-[16px] text-bone/75 leading-relaxed">

            Cuéntanos qué necesitas mover y diseñamos la solución. Respondemos cotizaciones en menos de 2 horas hábiles.

          </p>

        </div>



        <div className="lg:col-span-4 flex flex-col gap-3">

          <a href="https://wa.me/573125550188" target="_blank" rel="noopener"

             className="group flex items-center justify-between gap-3 px-6 h-16 font-semibold tracking-wide text-ink"

             style={{ background: accent }}>

            <span className="flex items-center gap-3">

              <Icon.Wa className="w-6 h-6"/>

              HABLAR POR WHATSAPP

            </span>

            <Icon.Arrow className="w-5 h-5 transition-transform group-hover:translate-x-1"/>

          </a>

          <a href="#contacto" className="group flex items-center justify-between gap-3 px-6 h-16 font-semibold tracking-wide border border-bone/30 hover:bg-bone hover:text-ink transition-colors">

            <span className="flex items-center gap-3">

              <Icon.Mail className="w-5 h-5"/>

              ENVIAR COTIZACIÓN

            </span>

            <Icon.Arrow className="w-5 h-5 transition-transform group-hover:translate-x-1"/>

          </a>

          <div className="mt-2 flex items-center gap-3 text-bone/55 text-[12.5px]">

            <Icon.Clock className="w-4 h-4"/>

            Respuesta en menos de 2 horas hábiles · L–S 7am · 7pm

          </div>

        </div>

      </div>

    </section>

  );

}



/* ─────────── FOOTER ─────────── */

function Footer({ accent }) {

  return (

    <footer id="contacto" className="relative bg-ink text-bone pt-24 pb-10">

      <div className="max-w-[1400px] mx-auto px-6 lg:px-10">

        <div className="grid lg:grid-cols-12 gap-10">

          <div className="lg:col-span-4">

            <div className="flex items-center gap-3">

              <span className="relative inline-flex items-center justify-center w-12 h-12 bg-bone text-ink font-head text-3xl leading-none pt-1">SM

                <span className="absolute -bottom-1 left-0 right-0 h-1" style={{ background: accent }}></span>

              </span>

              <div className="leading-tight">

                <div className="font-head text-2xl uppercase">Estibadores &amp; Montacargas</div>

                <div className="font-mono text-[10px] tracking-[0.25em] text-bone/55">SM · LOGÍSTICA INDUSTRIAL</div>

              </div>

            </div>

            <p className="mt-6 text-[14px] text-bone/65 leading-relaxed max-w-sm">

              Aliados estratégicos en el manejo de materiales para la industria del Valle. Equipos, técnicos y operarios bajo un mismo contrato.

            </p>



            <div className="mt-6 flex gap-2">

              {[

                { I: Icon.Wa,    href: 'https://wa.me/573125550188', l: 'WhatsApp' },

                { I: Icon.Insta, href: '#', l: 'Instagram' },

                { I: Icon.Fb,    href: '#', l: 'Facebook' },

                { I: Icon.Li,    href: '#', l: 'LinkedIn' },

              ].map((s, i) => (

                <a key={i} href={s.href} aria-label={s.l} className="w-10 h-10 grid place-items-center border border-bone/15 hover:border-bone/60 hover:text-amber transition-colors">

                  <s.I className="w-4 h-4"/>

                </a>

              ))}

            </div>

          </div>



          <div className="lg:col-span-3">

            <div className="font-mono text-[10.5px] tracking-[0.25em] text-bone/45 mb-4">CONTACTO</div>

            <ul className="space-y-3 text-[14px]">

              <li className="flex items-start gap-3"><Icon.Phone className="w-4 h-4 mt-0.5 text-amber shrink-0"/><span>+57 310 8247098<br/><span className="text-bone/50 text-[12px]">Línea operación 24/7</span></span></li>

              <li className="flex items-start gap-3"><Icon.Wa className="w-4 h-4 mt-0.5 text-amber shrink-0"/><span>+57 310 8247098<br/><span className="text-bone/50 text-[12px]">WhatsApp comercial</span></span></li>

              <li className="flex items-start gap-3"><Icon.Mail className="w-4 h-4 mt-0.5 text-amber shrink-0"/><span>comercial@sm-montacargas.co<br/><span className="text-bone/50 text-[12px]">Cotizaciones &amp; soporte</span></span></li>

            </ul>

          </div>



          <div className="lg:col-span-3">

            <div className="font-mono text-[10.5px] tracking-[0.25em] text-bone/45 mb-4">SEDE PRINCIPAL</div>

            <ul className="space-y-3 text-[14px]">

              <li className="flex items-start gap-3"><Icon.Pin className="w-4 h-4 mt-0.5 text-amber shrink-0"/><span>Cra. 68 #18-32, Zona Industrial<br/>Cali · Valle del Cauca</span></li>

              <li className="flex items-start gap-3"><Icon.Clock className="w-4 h-4 mt-0.5 text-amber shrink-0"/>

                <span>

                  Lun – Vie · 7:00 – 18:00<br/>

                  Sábado &nbsp;&nbsp;· 8:00 – 14:00<br/>

                  <span className="text-amber font-semibold">Emergencias 24/7</span>

                </span>

              </li>

            </ul>

          </div>



          <div className="lg:col-span-2">

            <div className="font-mono text-[10.5px] tracking-[0.25em] text-bone/45 mb-4">NAVEGAR</div>

            <ul className="space-y-2 text-[14px]">

              {[

                ['Inicio', '#hero'],

                ['Servicios', '#servicios'],

                ['Nosotros', '#nosotros'],

                ['Equipos', '#equipos'],

                ['Cotizar', '#contacto'],

              ].map(([t, h]) => (

                <li key={h}><a href={h} className="text-bone/70 hover:text-amber transition-colors">{t}</a></li>

              ))}

            </ul>

          </div>

        </div>



        <div className="mt-16 pt-6 border-t border-bone/10 flex flex-wrap items-center justify-between gap-4 font-mono text-[11px] text-bone/40 tracking-wider">

          <span>© 2026 ESTIBADORES Y MONTACARGAS SM · NIT 901.000.000-0</span>

          <span>POLÍTICA DE PRIVACIDAD · TÉRMINOS · TRATAMIENTO DE DATOS</span>

        </div>

      </div>

    </footer>

  );

}



Object.assign(window, { Services, WhyUs, Gallery, CTA, Footer });



/* ─────────── WORK IN ACTION ─────────── */

function WorkInAction({ accent }) {

    const photos = [
    { id: '27052026-DSC04339', src: 'editadas - personas/27052026-DSC04339_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04339' },
    { id: '27052026-DSC04423', src: 'editadas - personas/27052026-DSC04423_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04423' },
    { id: '27052026-DSC04461', src: 'editadas - personas/27052026-DSC04461_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04461' },
    { id: '27052026-DSC04468', src: 'editadas - personas/27052026-DSC04468_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04468' },
    { id: '27052026-DSC04499', src: 'editadas - personas/27052026-DSC04499_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04499' },
    { id: '27052026-DSC04553', src: 'editadas - personas/27052026-DSC04553_resultado_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04553' },
    { id: '27052026-DSC04724', src: 'editadas - personas/27052026-DSC04724_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04724' },
    { id: '27052026-DSC04748', src: 'editadas - personas/27052026-DSC04748_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04748' },
    { id: '27052026-DSC04760', src: 'editadas - personas/27052026-DSC04760_resultado_resultado.webp', alt: 'Registro de mantenimiento: 27052026-DSC04760' },
    { id: 'reparando_2', src: 'editadas - personas/reparando_2_resultado_resultado.webp', alt: 'Registro de mantenimiento: reparando_2' },
    { id: 'reparando_3', src: 'editadas - personas/reparando_3_resultado_resultado.webp', alt: 'Registro de mantenimiento: reparando_3' },
    { id: 'reparando_4', src: 'editadas - personas/reparando_4_resultado_resultado.webp', alt: 'Registro de mantenimiento: reparando_4' },
    { id: 'reparando_5', src: 'editadas - personas/reparando_5_resultado_resultado.webp', alt: 'Registro de mantenimiento: reparando_5' },
    { id: 'reparando_7', src: 'editadas - personas/reparando_7_resultado_resultado.webp', alt: 'Registro de mantenimiento: reparando_7' },
    { id: 'reparando_8', src: 'editadas - personas/reparando_8_resultado_resultado.webp', alt: 'Registro de mantenimiento: reparando_8' },
  ];



  return (

    <section id="trabajo" className="relative py-28 lg:py-36 bg-ink text-bone overflow-hidden">

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">

        <div className="mb-16">

          <div className="font-mono text-[11px] tracking-[0.3em] text-bone/60 mb-4">/ 04 — NUESTRO EQUIPO</div>

          <h2 className="font-head text-[clamp(44px,6vw,84px)] leading-[0.92] uppercase">

            Nuestro equipo <span style={{ color: accent }}>en acción</span>.

          </h2>

          <p className="mt-6 max-w-2xl text-[15px] text-bone/70 leading-relaxed">

            Personal técnico altamente calificado y equipado con herramientas de última generación para garantizar la máxima disponibilidad de sus equipos.

          </p>

        </div>



        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">

          {photos.map((p, i) => (

            <Reveal key={i} delay={i * 50}>

              <div className="group relative aspect-square overflow-hidden bg-bone/5 border border-bone/10">

                <img 

                  src={(window.__resources && window.__resources[p.id]) || p.src} 

                  decoding="async"

                  alt={p.alt} 

                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 scale-105 group-hover:scale-100"

                  loading="lazy"

                />

                <div className="absolute inset-0 bg-ink/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">

                  <p className="text-[12px] font-mono tracking-wider uppercase text-bone/90">{p.alt}</p>

                </div>

              </div>

            </Reveal>

          ))}

        </div>

      </div>

    </section>

  );

}



/* ─────────── TOOLS & PARTS ─────────── */

function ToolsParts({ accent }) {

  const categories = [

    { id: 'diag', t: 'Herramientas de Diagnóstico', d: 'Escáneres multimarca y software de programación para sistemas electrónicos.' },

    { id: 'parts', t: 'Repuestos Originales', d: 'Stock permanente de kits de sellos, mangueras, filtros y componentes críticos.' },

    { id: 'batt', t: 'Baterías y Cargadores', d: 'Soluciones de energía industrial: baterías de tracción y cargadores de alta eficiencia.' },

    { id: 'tires', t: 'Llantas Industriales', d: 'Venta e instalación de llantas sólidas y neumáticas de alta resistencia.' },

  ];



  const [active, setActive] = useState2('diag');
  const [page, setPage] = useState2(0);

  const normalizePath = (path) => String(path || '').replace(/\\/g, '/');
  const resources = (window.__resources_tools && window.__resources_tools[active]) || [];
  const orderedResources = resources.slice().sort((a, b) => {
    const aName = normalizePath(a.path || '').split('/').pop().toLowerCase();
    const bName = normalizePath(b.path || '').split('/').pop().toLowerCase();
    const aPriority = /^(?:([1-4])(?:\.webp)?)(?:$|[^\d])/.exec(aName)?.[1];
    const bPriority = /^(?:([1-4])(?:\.webp)?)(?:$|[^\d])/.exec(bName)?.[1];
    if (aPriority && bPriority) return Number(aPriority) - Number(bPriority);
    if (aPriority) return -1;
    if (bPriority) return 1;
    return aName.localeCompare(bName);
  });
  const pageCount = Math.max(1, Math.ceil(orderedResources.length / 4));
  const visiblePhotos = orderedResources.slice(page * 4, page * 4 + 4);

  return (

    <section id="herramientas" className="relative py-28 lg:py-36 bg-bone overflow-hidden">

      <div className="absolute inset-0 blueprint opacity-30 pointer-events-none"></div>

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10">

        <div className="grid lg:grid-cols-2 gap-16 items-start">

          <div>

            <div className="font-mono text-[11px] tracking-[0.3em] text-deep mb-4">/ 05 — SOPORTE TÉCNICO</div>

            <h2 className="font-head text-[clamp(44px,6vw,84px)] leading-[0.92] uppercase text-ink">

              Repuestos y<br/>

              <span className="underline-amber">Herramientas</span>.

            </h2>

            <p className="mt-8 text-[15px] text-ink/70 leading-relaxed">

              Seleccione una categoría para ver nuestras soluciones. Suministramos repuestos originales y herramientas de precisión para mantener su garantía.

            </p>

            

            <div className="mt-12 space-y-4">

              {categories.map((item, i) => (

                <Reveal key={item.id} delay={i * 100}>

                  <button 

                    onClick={() => { setActive(item.id); setPage(0); }}

                    className={`w-full text-left flex gap-6 p-4 transition-all border ${active === item.id ? 'bg-bone shadow-xl border-ink/10' : 'border-transparent hover:bg-ink/5'}`}

                  >

                    <div className={`w-12 h-12 shrink-0 flex items-center justify-center transition-colors ${active === item.id ? 'bg-amber text-ink' : 'bg-deep text-bone'}`}>

                      <span className="font-head text-2xl">{i + 1}</span>

                    </div>

                    <div>

                      <h3 className="font-head text-2xl uppercase text-ink">{item.t}</h3>

                      <p className={`mt-1 text-[14px] leading-snug transition-opacity ${active === item.id ? 'text-ink/80' : 'text-ink/60'}`}>{item.d}</p>

                    </div>

                  </button>

                </Reveal>

              ))}

            </div>

          </div>



          <div className="lg:sticky lg:top-32">

            <div className="grid grid-cols-2 gap-4">

              {(() => {

                const photos = visiblePhotos;

                return (photos.length > 0 ? photos : [1, 2, 3, 4]).map((p, i) => {

                  const n = i + 1;

                  const source = (p && p.path && normalizePath(p.path)) || (p && p.id && window.__resources && window.__resources[p.id]);
                  const isReal = !!source;

                  return (

                    <Reveal key={`${active}-${n}`} delay={n * 50}>

                      <div className="group relative aspect-[3/4] overflow-hidden bg-bone border border-ink/10 flex flex-col items-center justify-center text-center animate-in fade-in zoom-in duration-500">

                        {isReal ? (

                          <img 

                            src={source} 

                            decoding="async"

                            alt={active} 

                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"

                            loading="lazy"

                          />

                        ) : (

                          <Icon.Box className="w-10 h-10 text-deep/30 mb-4" />

                        )}

                        {!isReal && <div className="font-mono text-[10px] tracking-widest text-ink/40 uppercase">{active.toUpperCase()} - FOTO {n}</div>}

                        {!isReal && <div className="mt-2 text-[11px] text-ink/30 italic">Click para ampliar</div>}

                        

                        <div className="absolute inset-0 bg-ink/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">

                           <Icon.Arrow className="w-8 h-8 text-bone" />

                        </div>

                      </div>

                    </Reveal>

                  );

                });

              })()}
            </div>

            <div className="mt-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="inline-flex items-center gap-2">
                <button type="button" disabled={page <= 0} onClick={() => setPage(Math.max(page - 1, 0))} className={`px-4 py-3 text-sm font-semibold uppercase tracking-[0.2em] transition border ${page <= 0 ? 'border-ink/10 bg-ink/5 text-ink/40 cursor-not-allowed' : 'border-ink/20 bg-bone text-ink hover:border-ink'}`}>
                  Anterior
                </button>
                <button type="button" disabled={page >= pageCount - 1} onClick={() => setPage(Math.min(page + 1, pageCount - 1))} className={`px-4 py-3 text-sm font-semibold uppercase tracking-[0.2em] transition border ${page >= pageCount - 1 ? 'border-ink/10 bg-ink/5 text-ink/40 cursor-not-allowed' : 'border-ink/20 bg-bone text-ink hover:border-ink'}`}>
                  Siguiente
                </button>
              </div>
              <div className="font-mono text-[11px] tracking-widest uppercase text-ink/70">
                Página {page + 1} de {pageCount}
              </div>
            </div>

            <div className="mt-6 p-6 bg-ink text-bone font-mono text-[11px] tracking-widest uppercase flex items-center justify-between">

              <span>Categoría: {categories.find(c => c.id === active).t}</span>

              <span style={{ color: accent }}>● ACTIVE</span>

            </div>

          </div>

        </div>

      </div>

    </section>

  );

}



Object.assign(window, { WorkInAction, ToolsParts });



window.__resources_tools = {
    "diag": [
      {"id": "diag_num_1", "path": "editadas - herramientas\\herramientas de diagnostico\\1_resultado.webp"},
      {"id": "diag_num_2", "path": "editadas - herramientas\\herramientas de diagnostico\\2_resultado.webp"},
      {"id": "diag_num_3", "path": "editadas - herramientas\\herramientas de diagnostico\\3_resultado.webp"},
      {"id": "diag_num_4", "path": "editadas - herramientas\\herramientas de diagnostico\\4_resultado.webp"},
      {"id": "diag_Foto_Bomba_1_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_Bomba_1(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_Bomba_3_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_Bomba_3(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_Bomba_4_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_Bomba_4(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaLLaves_cerrada__3_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaLLaves(cerrada)_3(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaLLaves_enfocada__3_resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaLLaves(enfocada)_3_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaLLaves_enfocado__5_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaLLaves(enfocado)_5(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaLLaves_1_EditarFondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaLLaves_1(EditarFondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaLLaves_2_EditarFondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaLLaves_2(EditarFondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaVerde_Herramientas__Editar__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaVerde_Herramientas_(Editar)_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaVerde_Herramientas_1_Editar__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaVerde_Herramientas_1(Editar)_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaVerde_Herramientas_2_EditarFondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaVerde_Herramientas_2(EditarFondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_CajaVerde_Herramientas_3_EditarFondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_CajaVerde_Herramientas_3(EditarFondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_Craftsman_detalle__3_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_Craftsman(detalle)_3(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_Craftsman_1_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_Craftsman_1(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_Craftsman_2_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_Craftsman_2(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_Craftsman_4_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_Craftsman_4(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_HerramientaCajaVerde_1_EditarFondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_HerramientaCajaVerde_1(EditarFondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_HerramientaLLaves_2_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_HerramientaLLaves_2(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_HerramientaSata_1_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_HerramientaSata_1(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_HerramientaSata_2_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_HerramientaSata_2(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_HerramientaSata_3_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_HerramientaSata_3(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_Multimetro_2_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_Multimetro_2(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_taladro__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_taladro_(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_taladro_2_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_taladro_2(quitarfondo)_resultado_resultado.webp"},
      {"id": "diag_Foto_taladro_3_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\herramientas de diagnostico\\Foto_taladro_3(quitarfondo)_resultado_resultado.webp"}
    ],
    "parts": [
      {"id": "parts_num_1", "path": "editadas - herramientas\\repuestos originales\\1_resultado.webp"},
      {"id": "parts_num_2", "path": "editadas - herramientas\\repuestos originales\\2_resultado.webp"},
      {"id": "parts_num_3", "path": "editadas - herramientas\\repuestos originales\\3_resultado.webp"},
      {"id": "parts_num_4", "path": "editadas - herramientas\\repuestos originales\\4_resultado.webp"},
      {"id": "parts_Foto_Repuesto_1_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuesto_1(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Repuesto_2_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuesto_2(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Repuesto_3_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuesto_3(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Repuesto_4_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuesto_4(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Repuesto_detalle_1_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuesto_detalle_1(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Repuesto_detalle_2_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuesto_detalle_2(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Repuesto_izquierda_1_quitarlogo__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuesto_izquierda_1(quitarlogo)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoGeneral__quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoGeneral_(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoGeneral_1_quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoGeneral_1(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoGeneral_1Centro_quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoGeneral_1Centro(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoGeneral_1Derecho_quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoGeneral_1Derecho(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoGeneral_Derecha_quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoGeneral_Derecha(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoGeneral_Derecha1_quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoGeneral_Derecha1(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoGeneral_Derecha2_quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoGeneral_Derecha2(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoGeneral_Izquierda1_vertical_quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoGeneral_Izquierda1_vertical(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoOjos__quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoOjos_(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_repuestoOjos_1_quitarmarca__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_repuestoOjos_1(quitarmarca)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Repuestos_1_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuestos_1(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Repuestos_1Vertical_quitarfondo__resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuestos_1Vertical(quitarfondo)_resultado.webp"},
      {"id": "parts_Foto_Repuestos_2_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Repuestos_2(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_10_frontal__quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_10(frontal)(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_10_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_10(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_11_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_11(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_12_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_12(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_13_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_13(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_14_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_14(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_16_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_16(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_17_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_17(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_18_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_18(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_19_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_19(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_20_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_20(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_21_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_21(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_22_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_22(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_23_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_23(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_5_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_5(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_6_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_6(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_7_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_7(quitarfondo)_resultado_resultado.webp"},
      {"id": "parts_Foto_Respuesta_9_quitarfondo__resultado_resultado", "path": "editadas - herramientas\\repuestos originales\\Foto_Respuesta_9(quitarfondo)_resultado_resultado.webp"}
    ],
    "batt": [
      {"id": "batt_num_1", "path": "editadas - herramientas\\baterias y cargadores\\1_resultado.webp"},
      {"id": "batt_num_2", "path": "editadas - herramientas\\baterias y cargadores\\2_resultado.webp"},
      {"id": "batt_num_3", "path": "editadas - herramientas\\baterias y cargadores\\3_resultado.webp"},
      {"id": "batt_num_4", "path": "editadas - herramientas\\baterias y cargadores\\4_resultado.webp"},
      {"id": "batt_Sodexo_Montacargas_Horizontal2_resultado_resultado", "path": "editadas - herramientas\\baterias y cargadores\\Sodexo_Montacargas_Horizontal2_resultado_resultado.webp"},
      {"id": "batt_Sodexo_Montacargas_Vertical_resultado_resultado", "path": "editadas - herramientas\\baterias y cargadores\\Sodexo_Montacargas_Vertical_resultado_resultado.webp"}
    ],
    "tires": [
    ],
};
;

