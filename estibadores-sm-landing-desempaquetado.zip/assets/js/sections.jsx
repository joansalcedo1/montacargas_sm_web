// ───────────────────────────────────────────────────────────────
// Estibadores y Montacargas SM — page sections
// ───────────────────────────────────────────────────────────────

const { useEffect, useRef, useState } = React;
const Icon = window.Ico;

/* utility — counter that animates when scrolled into view */
function useInView(opts = { rootMargin: '0px 0px -10% 0px' }) {
  const ref = useRef(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    if (!ref.current) return;
    // If element already in viewport at mount, reveal immediately on next frame
    const r = ref.current.getBoundingClientRect();
    const vh = window.innerHeight || document.documentElement.clientHeight;
    if (r.top < vh * 0.95 && r.bottom > 0) {
      const id = requestAnimationFrame(() => setSeen(true));
      return () => cancelAnimationFrame(id);
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { setSeen(true); io.disconnect(); } });
    }, opts);
    io.observe(ref.current);
    return () => io.disconnect();
  }, []);
  return [ref, seen];
}

function Reveal({ as: As = 'div', className = '', delay = 0, children, ...rest }) {
  const [ref, seen] = useInView();
  return (
    <As ref={ref} className={`reveal ${seen ? 'in' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }} {...rest}>
      {children}
    </As>
  );
}

function CountUp({ to, suffix = '', prefix = '', duration = 1400 }) {
  const [ref, seen] = useInView();
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!seen) return;
    const start = performance.now();
    let raf;
    const tick = (t) => {
      const k = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - k, 3);
      setV(Math.round(eased * to));
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [seen, to, duration]);
  return <span ref={ref}>{prefix}{v}{suffix}</span>;
}

/* ─────────── NAV ─────────── */
function Nav({ accent }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 12);
    fn();
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);

  const links = [
    ['Inicio', '#hero'],
    ['Servicios', '#servicios'],
    ['Nosotros', '#nosotros'],
    ['Galería', '#trabajo'],
    ['Repuestos', '#herramientas'],
    ['Equipos', '#equipos'],
    ['Contacto', '#contacto'],
  ];

  return (
    <header className={`fixed top-0 inset-x-0 z-40 transition-all duration-300 ${scrolled ? 'bg-bone/90 backdrop-blur border-b border-black/5' : 'bg-transparent'}`}>
      <div className="max-w-[1400px] mx-auto px-6 lg:px-10 h-[72px] flex items-center gap-8">
        {/* Logo */}
        <a href="#hero" className="flex items-center gap-3 group">
          <span className="relative inline-flex items-center justify-center w-11 h-11 bg-ink text-bone font-head text-3xl leading-none tracking-tight pt-1">
            SM
            <span className="absolute -bottom-1 left-0 right-0 h-1" style={{ background: accent }}></span>
          </span>
          <span className="hidden sm:flex flex-col leading-none">
            <span className="font-head text-[22px] text-ink tracking-wide">ESTIBADORES &amp; MONTACARGAS</span>
            <span className="font-mono text-[10px] text-ink/60 tracking-[0.25em] mt-0.5">SM · LOGÍSTICA INDUSTRIAL</span>
          </span>
        </a>

        <nav className="hidden lg:flex items-center gap-7 ml-6">
          {links.map(([t, h]) => (
            <a key={h} href={h} className="text-[13.5px] font-medium text-ink/75 hover:text-ink transition-colors relative group">
              {t}
              <span className="absolute left-0 -bottom-1 h-[2px] w-0 group-hover:w-full transition-all" style={{ background: accent }}></span>
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <a href="#contacto" className="hidden md:inline-flex items-center gap-2 text-[13px] font-semibold text-ink/80 hover:text-ink pr-2">
            <Icon.Phone className="w-4 h-4"/> +57 310 8247098
          </a>
          <a href="#contacto"
             className="inline-flex items-center gap-2 px-4 lg:px-5 h-10 font-semibold text-[13px] tracking-wide text-ink hover:translate-y-[-1px] transition-transform"
             style={{ background: accent, boxShadow: `0 8px 24px -10px ${accent}` }}>
            SOLICITAR COTIZACIÓN
            <Icon.Arrow className="w-4 h-4"/>
          </a>
          <button onClick={() => setOpen(o => !o)} className="lg:hidden ml-1 w-10 h-10 flex flex-col items-center justify-center gap-1.5">
            <span className={`block w-5 h-[2px] bg-ink transition ${open ? 'translate-y-2 rotate-45' : ''}`}></span>
            <span className={`block w-5 h-[2px] bg-ink transition ${open ? 'opacity-0' : ''}`}></span>
            <span className={`block w-5 h-[2px] bg-ink transition ${open ? '-translate-y-2 -rotate-45' : ''}`}></span>
          </button>
        </div>
      </div>
      {open && (
        <div className="lg:hidden bg-bone border-b border-black/5 px-6 py-4 flex flex-col gap-3">
          {links.map(([t, h]) => (
            <a key={h} href={h} onClick={() => setOpen(false)} className="text-[15px] font-semibold text-ink/80">{t}</a>
          ))}
        </div>
      )}
    </header>
  );
}

/* ─────────── HERO ─────────── */
function Hero({ accent, title, sub, showTicker = true }) {
  // split user-provided title into 3 lines if possible for the big stacked layout
  const words = (title || 'Soluciones en Montacargas y Estibadores').trim().split(/\s+/);
  let l1 = words.slice(0, 2).join(' ');
  let l2 = words.slice(2, 4).join(' ');
  let l3 = words.slice(4).join(' ');
  if (!l3) { l1 = words.slice(0, Math.ceil(words.length/2)).join(' '); l2 = words.slice(Math.ceil(words.length/2)).join(' '); l3 = ''; }
  return (
    <section id="hero" className="relative min-h-[100vh] pt-[72px] overflow-hidden bg-ink text-bone">
      {/* placeholder photo */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 ph-stripes drift"></div>
        {/* faux forklift silhouette using simple geometry */}
        <svg className="absolute right-[-4%] bottom-[6%] w-[60%] max-w-[820px] opacity-[0.18]" viewBox="0 0 800 500" fill="none" stroke="#f5f4f0" strokeWidth="2">
          <path d="M120 360h360V180h120l60 100v80H120Z"/>
          <path d="M540 180v180M540 220h120"/>
          <path d="M120 200v160M120 200h40v160M180 200h40v160" strokeWidth="3"/>
          <circle cx="220" cy="380" r="40"/><circle cx="220" cy="380" r="14"/>
          <circle cx="440" cy="380" r="40"/><circle cx="440" cy="380" r="14"/>
        </svg>
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-ink/20"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent"></div>
        {/* tiny placeholder label */}
        <span className="absolute bottom-4 right-4 font-mono text-[10px] text-bone/40 tracking-[0.25em]">[ HERO · bodega + montacargas en operación ]</span>
      </div>

      {/* hazard strip */}
      <div className="absolute left-0 right-0 top-[72px] h-[6px] hazard opacity-90"></div>

      <div className="relative max-w-[1400px] mx-auto px-6 lg:px-10 pt-20 lg:pt-32 pb-24 grid lg:grid-cols-12 gap-10">
        <div className="lg:col-span-7">
          <Reveal className="inline-flex items-center gap-3 px-3 py-1.5 border border-bone/20 mb-8">
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: accent }}></span>
            <span className="font-mono text-[11px] tracking-[0.25em] text-bone/80">OPERANDO EN EL VALLE DEL CAUCA · 24/7</span>
          </Reveal>

          <Reveal delay={80}>
            <h1 className="font-head text-[clamp(56px,9vw,140px)] leading-[0.88] tracking-[0.005em] uppercase">
              {l1}<br/>
              {l2}{l3 ? <br/> : null}
              {l3 && (
                <span className="relative inline-block">
                  <span className="relative z-10">{l3}</span>
                  <span className="absolute left-0 right-0 bottom-[8%] h-[14px]" style={{ background: accent, opacity: 0.85 }}></span>
                </span>
              )}
            </h1>
          </Reveal>

          <Reveal delay={160} className="mt-8 max-w-[640px] text-[17px] leading-relaxed text-bone/75">
            {sub || 'Reparación especializada, mantenimiento y venta de repuestos para operaciones logísticas que no pueden detenerse. Equipos certificados, técnicos en sitio y respuesta en menos de 4 horas.'}
          </Reveal>

          <Reveal delay={240} className="mt-10 flex flex-wrap gap-3">
            <a href="#contacto"
               className="group inline-flex items-center gap-3 px-7 h-14 font-semibold tracking-wide text-ink"
               style={{ background: accent }}>
              COTIZAR AHORA
              <Icon.Arrow className="w-5 h-5 transition-transform group-hover:translate-x-1"/>
            </a>
            <a href="#servicios"
               className="group inline-flex items-center gap-3 px-7 h-14 font-semibold tracking-wide text-bone border border-bone/30 hover:bg-bone hover:text-ink transition-colors">
              NUESTROS SERVICIOS
            </a>
          </Reveal>

          {/* hero meta strip */}
          <Reveal delay={320} className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-px bg-bone/10 max-w-[760px]">
            {[
              ['10+', 'AÑOS', 'operando'],
              ['<4h', 'RESPUESTA', 'en sitio'],
              ['450', 'EQUIPOS', 'atendidos'],
              ['24/7', 'SOPORTE', 'técnico'],
            ].map(([n, k, s]) => (
              <div key={k} className="bg-ink px-5 py-4">
                <div className="font-head text-4xl leading-none" style={{ color: accent }}>{n}</div>
                <div className="mt-2 font-mono text-[10px] tracking-[0.25em] text-bone/60">{k}</div>
                <div className="text-[12px] text-bone/70">{s}</div>
              </div>
            ))}
          </Reveal>
        </div>

        {/* featured repair image replacing spec card */}
        <div className="lg:col-span-5 lg:pt-6 hidden lg:block">
          <Reveal delay={400} className="relative group">
            <div className="absolute -top-4 -left-4 w-full h-full border border-bone/10 transition-transform group-hover:translate-x-1 group-hover:translate-y-1"></div>
            <div className="relative aspect-[4/5] overflow-hidden border border-bone/15 shadow-2xl">
              <img 
                src={window.__resources && window.__resources["reparando_4"]} 
                alt="Reparación de montacargas" 
                className="w-full h-full object-contain bg-ink/40 grayscale-[0.2] hover:grayscale-0 transition-all duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-5 left-5 right-5">
                <div className="font-mono text-[10px] tracking-[0.3em] text-bone/60 uppercase mb-2">Servicio Técnico</div>
                <div className="font-head text-2xl text-bone uppercase leading-tight">Mantenimiento Especializado en Sitio</div>
              </div>
            </div>
            {/* hazard accent corner */}
            <div className="absolute -bottom-3 -right-3 w-16 h-16 hazard opacity-80 shadow-lg"></div>
          </Reveal>
        </div>
      </div>

      {/* logo marquee */}
      {showTicker && (
      <div className="relative border-t border-bone/10 py-5 overflow-hidden">
        <div className="flex marquee-track gap-16 whitespace-nowrap">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="flex items-center gap-16 font-mono text-[12px] tracking-[0.3em] text-bone/40 uppercase">
              <span>Bavaria</span><span>·</span><span>Postobón</span><span>·</span><span>Grupo Éxito</span><span>·</span>
              <span>Cementos Argos</span><span>·</span><span>Crepes &amp; Waffles</span><span>·</span><span>Almacenes Si</span><span>·</span>
              <span>Tecnoquímicas</span><span>·</span><span>Bimbo</span><span>·</span><span>Premex</span><span>·</span>
            </div>
          ))}
        </div>
      </div>
      )}
    </section>
  );
}
window.Nav = Nav;
window.Hero = Hero;
window.Reveal = Reveal;
window.CountUp = CountUp;
